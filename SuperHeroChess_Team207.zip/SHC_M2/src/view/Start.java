package view;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Start extends JFrame implements ActionListener {
	
	public Start() {
		this.setBounds(0, 0, 1500, 1000);
		this.setTitle("Superhero Chess");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.getContentPane().setBackground(Color.BLACK);
		JButton b= new JButton("");
		Image img16 = new ImageIcon(this.getClass().getResource("/bk-new.jpg")).getImage();
		b.setIcon(new ImageIcon(img16));	
		b.addActionListener(this);
		this.getContentPane().add(b);
		this.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals(""))
			this.dispose();
			new Window();
	}
	public static void main(String [] args) {
		new Start();
	}
}
