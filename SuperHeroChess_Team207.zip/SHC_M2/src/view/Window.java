package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import model.game.*;
import model.pieces.*;
import model.pieces.heroes.*;
import model.pieces.sidekicks.*;
import exceptions.*;

@SuppressWarnings("serial")
public class Window extends JFrame implements ActionListener {
	private JPanel board, payloadP1, payloadP2, buttons, dropdown, south, player1P, player2P;
	private JButton b1, b2, b3, undo, usepower, up, down, right, left, upright, upleft, downright, downleft, move, exit,
			ButtonP1, ButtonP2, cp;
	private JLabel label1, label2;
	private Player player1;
	private Player player2;
	private String Player1, Player2;
	private Game g;
	private final JButton[][] btnpieces = new JButton[7][6];
	private JButton directionPressed = null, piecePressed = null, movePressed = null, powerPressed = null, 
			targetPressed = null, cellPressed = null;
	private Direction direction;
	private Piece revive;

	public Window() {
		this.setBounds(0, 0, 1500 , 1000);
		this.setTitle("Superhero Chess");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		//this.getContentPane().setBackground(Color.black);
		this.getContentPane().setLayout(new BorderLayout());
		JButton btn1 = new JButton("");
		Image img17 = new ImageIcon(this.getClass().getResource("/justice-league.jpg")).getImage();
		btn1.setIcon(new ImageIcon(img17));
		this.getContentPane().add(btn1);
		this.setVisible(true);
		
		Player1 = JOptionPane.showInputDialog(this, "Player 1 ", null);
		this.getContentPane().remove(btn1);
		JButton btn2 = new JButton("");
		Image img18 = new ImageIcon(this.getClass().getResource("/avengers3.jpg")).getImage();
		btn2.setIcon(new ImageIcon(img18));
		this.getContentPane().add(btn2);
		this.setVisible(true);
		Player2 = JOptionPane.showInputDialog(this, "Player 2 ", null);
		player1 = new Player(Player1);
		player2 = new Player(Player2);
		this.getContentPane().remove(btn2);
		this.setVisible(true);
		board = new JPanel();
		board.setBackground(Color.WHITE);
		board.setLayout(new GridLayout(7, 6));
		g = new Game(player1, player2);

		this.initialiseBoard(); // board
		this.initialisePayloadP1(); // PayloadP1
		this.initialisePayloadP2(); // PayloadP2

		buttons = new JPanel(); // Movement,Using Power & Exit Game buttons
		buttons.setLayout(new GridLayout(3, 3));
		up = new JButton();
		down = new JButton();
		right = new JButton();
		left = new JButton();
		upleft = new JButton();
		upright = new JButton();
		downleft = new JButton();
		downright = new JButton();
		usepower = new JButton("Use Power");
		Image img3 = new ImageIcon(this.getClass().getResource("/battery.png")).getImage();
		usepower.setIcon(new ImageIcon(img3));
		move = new JButton("Move");
		Image img1 = new ImageIcon(this.getClass().getResource("/move.png")).getImage();
		move.setIcon(new ImageIcon(img1));
		undo = new JButton("UNDO");
		exit = new JButton("Exit Game");
		Image img2 = new ImageIcon(this.getClass().getResource("/exit.png")).getImage();
		exit.setIcon(new ImageIcon(img2));
		buttons.add(upleft);
		buttons.add(up);
		buttons.add(upright);
		buttons.add(left);
		buttons.add(undo);
		buttons.add(right);
		buttons.add(downleft);
		buttons.add(down);
		buttons.add(downright);
		buttons.add(usepower);
		buttons.add(move);
		buttons.add(exit);
		up.addActionListener(this);
		Image img5 = new ImageIcon(this.getClass().getResource("/up.png")).getImage();
		up.setIcon(new ImageIcon(img5));
		down.addActionListener(this);
		Image img6 = new ImageIcon(this.getClass().getResource("/ana taweela.png")).getImage();
		down.setIcon(new ImageIcon(img6));
		right.addActionListener(this);
		Image img4 = new ImageIcon(this.getClass().getResource("/right.png")).getImage();
		right.setIcon(new ImageIcon(img4));
		left.addActionListener(this);
		Image img7 = new ImageIcon(this.getClass().getResource("/left.png")).getImage();
		left.setIcon(new ImageIcon(img7));
		upleft.addActionListener(this);
		Image img8 = new ImageIcon(this.getClass().getResource("/upleft.png")).getImage();
		upleft.setIcon(new ImageIcon(img8));
		upright.addActionListener(this);
		Image img9 = new ImageIcon(this.getClass().getResource("/upright.png")).getImage();
		upright.setIcon(new ImageIcon(img9));
		downleft.addActionListener(this);
		Image img10 = new ImageIcon(this.getClass().getResource("/downleft.png")).getImage();
		downleft.setIcon(new ImageIcon(img10));
		downright.addActionListener(this);
		Image img11 = new ImageIcon(this.getClass().getResource("/downright.png")).getImage();
		downright.setIcon(new ImageIcon(img11));
		usepower.addActionListener(this);
		move.addActionListener(this);
		exit.addActionListener(this);
		undo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				directionPressed = null; // reset
				movePressed = null;
				piecePressed = null;
				powerPressed = null;
				targetPressed = null;
				cellPressed = null;
				revive=null;
			}
		});
		Image img82 = new ImageIcon(this.getClass().getResource("/undo.png")).getImage();
		undo.setIcon(new ImageIcon(img82));
		JPanel buttons2 = new JPanel(new GridLayout(1,3));
		buttons2.setBackground(Color.BLACK);
		buttons2.add(usepower);
		buttons2.add(move);
		buttons2.add(exit);
		
		south = new JPanel();
		south.setLayout(new BorderLayout());
		south.add(buttons, BorderLayout.EAST);
		south.add(buttons2, BorderLayout.CENTER);
		this.initialiseDropdown();

		player1P = new JPanel(); // Player1
		player1P.setLayout(new BorderLayout());
		ButtonP1 = new JButton("Player 1: " + Player1);
		ButtonP1.setBackground(Color.decode("#C0C0C0"));
		ButtonP1.addActionListener(this);
		player1P.add(ButtonP1, BorderLayout.CENTER);
		south.add(player1P, BorderLayout.NORTH);

		cp = new JButton("Current Player: " + "'" + g.getCurrentPlayer().getName() + "'"); // CurrentPlayer
		cp.setBackground(Color.decode("#C0C0C0"));
		south.add(cp, BorderLayout.SOUTH);
		this.getContentPane().add(south, BorderLayout.SOUTH);

		player2P = new JPanel(); // Player2
		player2P.setLayout(new BorderLayout());
		ButtonP2 = new JButton("Player2: " + Player2);
		ButtonP2.setBackground(Color.decode("#C0C0C0"));
		ButtonP2.addActionListener(this);
		player2P.add(ButtonP2, BorderLayout.CENTER);
		this.getContentPane().add(player2P, BorderLayout.NORTH);
		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Exit Game")) {
			int result= JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?");
			if(JOptionPane.YES_OPTION == result)
				this.dispose();
		}
		if (e.getActionCommand().equals("Player 1: " + Player1))
			JOptionPane.showMessageDialog(null, "Player1: " + Player1 + " " + "Team: Justice League " + " Payload= " + player1.getPayloadPos());
		if (e.getActionCommand().equals("Player2: " + Player2))
			JOptionPane.showMessageDialog(null, "Player2: " + Player2 + " " + "Team: Avengers " + " Payload= " + player2.getPayloadPos());
		// get the JButton that was clicked
		if (e.getSource() instanceof JComboBox) {
			@SuppressWarnings("rawtypes")
			JComboBox cb = (JComboBox) e.getSource();
			if (revive == null) {
				revive = (Piece) cb.getSelectedItem();
				System.out.println("Revive Pressed");
				return;
			}
			else 
				return;
		}
		
		JButton x = (JButton) e.getSource();
		if (x == up) {
			directionPressed = up;
			direction = Direction.UP;
			return;
		} else if (x == down) {
			directionPressed = down;
			direction = Direction.DOWN;
			return;
		} else if (x == left) {
			directionPressed = left;
			direction = Direction.LEFT;
			return;
		} else if (x == right) {
			directionPressed = right;
			direction = Direction.RIGHT;
			return;
		} else if (x == upleft) {
			directionPressed = upleft;
			direction = Direction.UPLEFT;
			return;
		} else if (x == upright) {
			directionPressed = upright;
			direction = Direction.UPRIGHT;
			return;
		} else if (x == downleft) {
			directionPressed = downleft;
			direction = Direction.DOWNLEFT;
			return;
		} else if (x == downright) {
			directionPressed = downright;
			direction = Direction.DOWNRIGHT;
			return;
		}

		if (x.getActionCommand() == move.getActionCommand())
			movePressed = x;
		else if (x.getActionCommand() == usepower.getActionCommand()) {
			powerPressed = x;
			System.out.println("POWER Pressed YES");
		} else if (piecePressed == null) {
			piecePressed = x;
			System.out.println("Piece Pressed YES");
			return;
		} else if (targetPressed == null) {
			targetPressed = x;
			System.out.println("TARGET Pressed YES");
			return;
		} else if (cellPressed == null) {
			cellPressed = x;
			System.out.println("CELL Pressed YES");
			return;
		}

		if (directionPressed != null && movePressed != null && piecePressed != null && powerPressed == null && revive==null) {// MOOOOOVVVVEEEEEEE
			Point point = getindex(btnpieces, piecePressed);
			Piece p = g.getCellAt((int) point.getX(), (int) point.getY()).getPiece();
			try {
				p.move(direction);
				this.updateBoard();
				this.updateDropdown();
				this.updatePayloads();
			} catch (UnallowedMovementException | OccupiedCellException | WrongTurnException e1) {
				directionPressed = null; // reset
				movePressed = null;
				piecePressed = null;
				powerPressed = null;
				targetPressed = null;
				cellPressed = null;
				revive=null;
				JOptionPane.showMessageDialog(null, e1.getMessage(), e1.getMessage(), JOptionPane.ERROR_MESSAGE);
			}
		} else if (directionPressed == null && piecePressed != null && targetPressed != null && powerPressed != null
				&& cellPressed == null && revive==null) {// hack aw restore
			Point point = getindex(btnpieces, piecePressed);
			Piece tech = g.getCellAt((int) point.getX(), (int) point.getY()).getPiece();
			if (tech instanceof Tech) {
				Point point2 = getindex(btnpieces, targetPressed);
				Piece target = g.getCellAt((int) point2.getX(), (int) point2.getY()).getPiece();
				try {
					((Tech) tech).usePower(null, target, null);
					this.updateBoard();
					this.updateDropdown();
					this.updatePayloads();
				} catch (InvalidPowerUseException | WrongTurnException e1) {
					directionPressed = null; // reset
					movePressed = null;
					piecePressed = null;
					powerPressed = null;
					targetPressed = null;
					cellPressed = null;
					revive=null;
					JOptionPane.showMessageDialog(null, e1.getMessage(), e1.getMessage(), JOptionPane.ERROR_MESSAGE);
				}
			}
		} else if (directionPressed == null && piecePressed != null && targetPressed != null && powerPressed != null
				&& cellPressed != null && revive==null) { // teleport
			Point point = getindex(btnpieces, piecePressed);
			Piece tech = g.getCellAt((int) point.getX(), (int) point.getY()).getPiece();
			if (tech instanceof Tech) {
				Point point2 = getindex(btnpieces, targetPressed);
				Piece target = g.getCellAt((int) point2.getX(), (int) point2.getY()).getPiece();
				Point newPos = getindex(btnpieces, cellPressed);
				try {
					((Tech) tech).usePower(null, target, newPos);
					this.updateBoard();
					this.updateDropdown();
					this.updatePayloads();
				} catch (InvalidPowerUseException | WrongTurnException e1) {
					directionPressed = null; // reset
					movePressed = null;
					piecePressed = null;
					powerPressed = null;
					targetPressed = null;
					cellPressed = null;
					revive=null;
					JOptionPane.showMessageDialog(null, e1.getMessage(), e1.getMessage(), JOptionPane.ERROR_MESSAGE);
				}
			}
		} else if (directionPressed != null && piecePressed != null && targetPressed == null && powerPressed != null
				&& cellPressed == null && revive==null) { // ranged aw super poweruse
			Point point = getindex(btnpieces, piecePressed);
			Piece piece = g.getCellAt((int) point.getX(), (int) point.getY()).getPiece();
			if (piece instanceof Ranged) {// ranged use power
				try {
					((Ranged) piece).usePower(direction, null, null);
					this.updateBoard();
					this.updateDropdown();
					this.updatePayloads();
				} catch (InvalidPowerUseException | WrongTurnException e1) {
					directionPressed = null; // reset
					movePressed = null;
					piecePressed = null;
					powerPressed = null;
					targetPressed = null;
					cellPressed = null;
					revive=null;
					JOptionPane.showMessageDialog(null, e1.getMessage(), e1.getMessage(), JOptionPane.ERROR_MESSAGE);
				}
			} else if (piece instanceof Super) {// super use power
				try {
					((Super) piece).usePower(direction, null, null);
					this.updateBoard();
					this.updateDropdown();
					this.updatePayloads();
				} catch (InvalidPowerUseException | WrongTurnException e1) {
					directionPressed = null; // reset
					movePressed = null;
					piecePressed = null;
					powerPressed = null;
					targetPressed = null;
					cellPressed = null;
					revive=null;
					JOptionPane.showMessageDialog(null, e1.getMessage(), e1.getMessage(), JOptionPane.ERROR_MESSAGE);
				}
			}
		}
		else 
			if(directionPressed!=null && piecePressed!=null && revive!=null 
			&& powerPressed!=null && cellPressed==null) { //Medic use power
				Point point= getindex(btnpieces, piecePressed);
				Piece piece= g.getCellAt((int) point.getX(), (int) point.getY()).getPiece();
				if(piece instanceof Medic) {
					try {
						((Medic) piece).usePower(direction, revive, null);
						this.updateBoard();
						this.updateDropdown();
						this.updatePayloads();
					} catch (InvalidPowerUseException | WrongTurnException e1) {
						directionPressed = null; // reset
						movePressed = null;
						piecePressed = null;
						powerPressed = null;
						targetPressed = null;
						cellPressed = null;
						revive=null;
						JOptionPane.showMessageDialog(null, "medic", e1.getMessage(), JOptionPane.ERROR_MESSAGE);
					}
				}
			}
	}

	public void initialiseDropdown() {
		dropdown = new JPanel(); // DeadCharacters
		dropdown.setLayout(new GridLayout(2, 2));
		label1 = new JLabel("Dead Characters:" + " " + Player1 + "- ");
		label2 = new JLabel("Dead Characters:" + " " + Player2);
		String[] deadCharacters1 = { "" };
		final JComboBox<String> cb1 = new JComboBox<String>(deadCharacters1);
		String[] deadCharacters2 = { "" };
		final JComboBox<String> cb2 = new JComboBox<String>(deadCharacters2);
		dropdown.add(label1);
		dropdown.add(label2);
		dropdown.add(cb1);
		dropdown.add(cb2);
		cb1.addActionListener(this);
		cb2.addActionListener(this);
		south.add(dropdown, BorderLayout.WEST);
		this.setVisible(true);
	}

	public void updateDropdown() {
		JPanel updatedDW = new JPanel();
		updatedDW.setLayout(new GridLayout(2, 2));
		JComboBox<Piece> DC1 = new JComboBox<Piece>();
		JComboBox<Piece> DC2 = new JComboBox<Piece>();
		JLabel lbl1 = new JLabel("Dead Characters" + " " + Player1 + "-");
		JLabel lbl2 = new JLabel("Dead Characters" + " " + Player2);

		for (int i = 0; i < player1.getDeadCharacters().size(); i++)
			DC1.addItem(player1.getDeadCharacters().get(i));

		for (int j = 0; j < player2.getDeadCharacters().size(); j++)
			DC2.addItem(player2.getDeadCharacters().get(j));

		updatedDW.add(lbl1);
		updatedDW.add(lbl2);
		updatedDW.add(DC1);
		updatedDW.add(DC2);
		DC1.addActionListener(this);
		DC2.addActionListener(this);
		this.getContentPane().remove(dropdown);
		south.remove(dropdown);
		dropdown = updatedDW;
		south.add(dropdown, BorderLayout.WEST);
		this.setVisible(true);
	}

	public void initialisePayloadP1() {
		payloadP1 = new JPanel(); // payload1
		payloadP1.setLayout(new GridLayout(8, 1));
		payloadP1.setBackground(Color.WHITE);
		JLabel labelp1 = new JLabel("Payload" + " " + Player1);
		payloadP1.add(labelp1);
		for (int k = 1; k <= 6; k++) {
			b2 = new JButton();
			b2.setBackground(Color.WHITE); //greyy
			payloadP1.add(b2);
		}
		JLabel w1 = new JLabel(Player1 + " Wins " + "!");
		payloadP1.add(w1);
		this.getContentPane().add(payloadP1, BorderLayout.WEST);
		this.setVisible(true);
	}

	public void initialisePayloadP2() {
		payloadP2 = new JPanel(); // payload2
		payloadP2.setLayout(new GridLayout(8, 1));
		payloadP2.setBackground(Color.decode("#0073ef"));
		JLabel labelp2 = new JLabel("Payload" + " " + Player2);
		labelp2.setForeground(Color.RED);
		payloadP2.add(labelp2);
		for (int k = 1; k <= 6; k++) {
			b3 = new JButton();
			b3.setBackground(Color.decode("#0073ef")); //blue
			b3.setForeground(Color.WHITE);
			payloadP2.add(b3);
		}
		JLabel w2 = new JLabel(Player2 +" Wins " +  "!");
		w2.setForeground(Color.RED);
		payloadP2.add(w2);
		this.getContentPane().add(payloadP2, BorderLayout.EAST);
		this.setVisible(true);
	}

	public void updatePayloads() {
		JPanel pl1Updated = new JPanel();
		pl1Updated.setLayout(new GridLayout(8, 1));
		pl1Updated.setBackground(Color.WHITE);
		int i, j;
		JPanel pl2Updated = new JPanel();
		pl2Updated.setLayout(new GridLayout(8, 1));
		pl2Updated.setBackground(Color.decode("#0073ef"));
		
		JLabel labelp1 = new JLabel("Payload" + " " + Player1);
		pl1Updated.add(labelp1);
		for (i = 1; i <= player1.getPayloadPos(); i++) {    //Change buttons
			JButton b2 = new JButton();
			b2.setBackground(Color.WHITE);
			Image img2 = new ImageIcon(this.getClass().getResource("/jl.jpg")).getImage();
			b2.setIcon(new ImageIcon(img2));
			pl1Updated.add(b2);
		}
		for (; i <= 6; i++) {                               //the rest
			JButton b2 = new JButton();
			b2.setBackground(Color.WHITE);
			pl1Updated.add(b2);
		}
		JLabel w1 = new JLabel( Player1 + " Wins " + "!");
		pl1Updated.add(w1);
		this.getContentPane().remove(payloadP1);
		payloadP1 = pl1Updated;
		this.getContentPane().add(payloadP1, BorderLayout.WEST);

		JLabel labelp2 = new JLabel("Payload" + " " + Player2);    
		labelp2.setForeground(Color.RED);
		pl2Updated.add(labelp2);
		
		for (j = 1; j <= player2.getPayloadPos(); j++) {	//Change buttons
			JButton b2 = new JButton();
			b2.setBackground(Color.decode("#0073ef"));   
			Image img1 = new ImageIcon(this.getClass().getResource("/avengersicon2.png")).getImage();
			b2.setIcon(new ImageIcon(img1));
			pl2Updated.add(b2);
		}
		for (; j <= 6; j++) {
			JButton b2 = new JButton();
			b2.setBackground(Color.decode("#0073ef"));
			b2.setForeground(Color.WHITE);
			pl2Updated.add(b2);
		}
		JLabel w2 = new JLabel(Player2 + " Wins " + "!");
		w2.setForeground(Color.RED);
		pl2Updated.add(w2);
		this.getContentPane().remove(payloadP2);
		payloadP2 = pl2Updated;
		this.getContentPane().add(payloadP2, BorderLayout.EAST);
		this.setVisible(true);
		if (g.getPlayer1().getPayloadPos()==6 || g.getPlayer2().getPayloadPos()==6) {
			String s;
			if(g.getPlayer1().getPayloadPos()==6)
				s = "Congrats, " + g.getPlayer1().getName() + " you won!";
			else 
				s= "Congrats, " + g.getPlayer2().getName() + " you won!";
			JOptionPane.showMessageDialog(null, s, "Winner available!", JOptionPane.INFORMATION_MESSAGE);
			this.dispose();
		}
	}

	public void initialiseBoard() {
		board = new JPanel();
		board.setLayout(new GridLayout(7, 6));
		for (int i = 0; i < 7; i++) { // board
			for (int j = 0; j < 6; j++) {
				if (g.getCellAt(i, j).getPiece() != null) {
					Piece p = g.getCellAt(i, j).getPiece();
					b1 = new JButton(p.getName());
					if (p instanceof ActivatablePowerHero) {
						b1.setToolTipText("Name: " + p.getName() + " Type: " + p.getType() + " PowerUsed: "
								+ ((ActivatablePowerHero) p).isPowerUsed() + " Owner: " + p.getOwner());
					} else if (p instanceof Armored)
						b1.setToolTipText("Name: " + p.getName() + " Type: " + p.getType() 
							+ " ArmourUp: "+ ((Armored) p).isArmorUp() + " Owner: " + p.getOwner()); 
					else 
						b1.setToolTipText("Name: " + p.getName() + " Type: " + p.getType() + " Owner: " + p.getOwner()); 
					if (p instanceof Super && p.getOwner()==player2) {
						Image img1 = new ImageIcon(this.getClass().getResource("/hulk.png")).getImage();
						b1.setIcon(new ImageIcon(img1));
					}
					if (p instanceof Tech && p.getOwner()==player1) {
						Image img2 = new ImageIcon(this.getClass().getResource("/batman-2.png.png")).getImage();
						b1.setIcon(new ImageIcon(img2));
					}
					if (p instanceof Tech && p.getOwner()==player2) {
						Image img3 = new ImageIcon(this.getClass().getResource("/ironman.png"))
								.getImage();
						b1.setIcon(new ImageIcon(img3));
					}
					if (p instanceof Armored && p.getOwner()==player2) {
						Image img4 = new ImageIcon(this.getClass().getResource("/captainamerica.png"))
								.getImage();
						b1.setIcon(new ImageIcon(img4));
					}
					if (p instanceof Ranged && p.getOwner()==player2) {
						Image img5 = new ImageIcon(this.getClass().getResource("/hawkeye.png"))
								.getImage();
						b1.setIcon(new ImageIcon(img5));
					}
					if (p instanceof Super && p.getOwner()==player1) {
						Image img6 = new ImageIcon(this.getClass().getResource("/superman.png")).getImage();
						b1.setIcon(new ImageIcon(img6));
					}
					if (p instanceof Armored && p.getOwner()==player1) {
						Image img7 = new ImageIcon(this.getClass().getResource("/wonderw.png")).getImage();
						b1.setIcon(new ImageIcon(img7));
					}
					if (p instanceof SideKick && p.getOwner()==player1) {
						Image img8 = new ImageIcon(this.getClass().getResource("/penguin.png")).getImage();
						b1.setIcon(new ImageIcon(img8));
					}
					if (p instanceof SideKick && p.getOwner()==player2) {
						Image img9 = new ImageIcon(this.getClass().getResource("/spiderman.png")).getImage();
						b1.setIcon(new ImageIcon(img9));

					}
					if (p instanceof Speedster && p.getOwner()==player1) {
						Image img10 = new ImageIcon(this.getClass().getResource("/flash.png")).getImage();
						b1.setIcon(new ImageIcon(img10));
					}
					if (p instanceof Medic && p.getOwner()==player2) {
						Image img11 = new ImageIcon(this.getClass().getResource("/coulson.png")).getImage();
						b1.setIcon(new ImageIcon(img11));
					}
					if (p instanceof Ranged && p.getOwner()==player1) {
						Image img12 = new ImageIcon(this.getClass().getResource("/greena.png")).getImage();
						b1.setIcon(new ImageIcon(img12));
					}
					if (p instanceof Medic && p.getOwner()==player1) {
						Image img13 = new ImageIcon(this.getClass().getResource("/greenlanetrn.png")).getImage();
						b1.setIcon(new ImageIcon(img13));
					}
					if (p instanceof Speedster && p.getOwner()==player2) {
						Image img14 = new ImageIcon(this.getClass().getResource("/sonic.png")).getImage();
						b1.setIcon(new ImageIcon(img14));
					}
				} else
					b1 = new JButton("");
				btnpieces[i][j] = b1;
				b1.addActionListener(this);
			//	if ((i + j) % 2 == 0) {
					b1.setBackground(Color.black);
					b1.setForeground(Color.WHITE);
			//	} else {
			//		b1.setBackground(Color.WHITE);
			//	}
				board.add(b1);
			}
		}
		this.getContentPane().add(board, BorderLayout.CENTER);
	}

	public void updateBoard() {
		if (g.checkWinner()) {
			String s = "Congrats! " + g.getCurrentPlayer().getName() + "\n" + "You won!";
			JOptionPane.showMessageDialog(null, "Winner Available!", s, JOptionPane.ERROR_MESSAGE);
			this.dispose();
		}
		JPanel updatedBoard = new JPanel();
		updatedBoard.setLayout(new GridLayout(7, 6));
		JButton b2;
		for (int i = 0; i < 7; i++) { // board
			for (int j = 0; j < 6; j++) {
				if (g.getCellAt(i, j).getPiece() != null) {
					Piece p = g.getCellAt(i, j).getPiece();
					b2 = new JButton(p.getName());
					if (p instanceof ActivatablePowerHero) {
						b2.setToolTipText("Name: " + p.getName() + " Type: " + p.getType() + " PowerUsed: "
								+ ((ActivatablePowerHero) p).isPowerUsed() + " Owner: " + p.getOwner());
					} else if (p instanceof Armored)
						b2.setToolTipText("Name: " + p.getName() + " Type: " + p.getType() 
							+ " ArmourUp: "+ ((Armored) p).isArmorUp() + " Owner: " + p.getOwner()); 
					else 
						b2.setToolTipText("Name: " + p.getName() + " Type: " + p.getType() + " Owner: " + p.getOwner()); 
					if (p instanceof Super && p.getOwner()==player2) {
						Image img1 = new ImageIcon(this.getClass().getResource("/hulk.png")).getImage();
						b2.setIcon(new ImageIcon(img1));
					}
					if (p instanceof Tech && p.getOwner()==player1) {
						Image img2 = new ImageIcon(this.getClass().getResource("/batman-2.png.png")).getImage();
						b2.setIcon(new ImageIcon(img2));
					}
					if (p instanceof Tech && p.getOwner()==player2) {
						Image img3 = new ImageIcon(this.getClass().getResource("/ironman.png"))
								.getImage();
						b2.setIcon(new ImageIcon(img3));
					}
					if (p instanceof Armored && p.getOwner()==player2) {
						Image img4 = new ImageIcon(this.getClass().getResource("/captainamerica.png"))
								.getImage();
						b2.setIcon(new ImageIcon(img4));
					}
					if (p instanceof Ranged && p.getOwner()==player2) {
						Image img5 = new ImageIcon(this.getClass().getResource("/hawkeye.png"))
								.getImage();
						b2.setIcon(new ImageIcon(img5));
					}
					if (p instanceof Super && p.getOwner()==player1) {
						Image img6 = new ImageIcon(this.getClass().getResource("/superman.png")).getImage();
						b2.setIcon(new ImageIcon(img6));
					}
					if (p instanceof Armored && p.getOwner()==player1) {
						Image img7 = new ImageIcon(this.getClass().getResource("/wonderw.png")).getImage();
						b2.setIcon(new ImageIcon(img7));
					}
					if (p instanceof SideKick && p.getOwner()==player1) {
						Image img8 = new ImageIcon(this.getClass().getResource("/penguin.png")).getImage();
						b2.setIcon(new ImageIcon(img8));
					}
					if (p instanceof SideKick && p.getOwner()==player2) {
						Image img9 = new ImageIcon(this.getClass().getResource("/spiderman.png")).getImage();
						b2.setIcon(new ImageIcon(img9));
					}
					if (p instanceof Speedster && p.getOwner()==player1) {
						Image img10 = new ImageIcon(this.getClass().getResource("/flash.png")).getImage();
						b2.setIcon(new ImageIcon(img10));
					}
					if (p instanceof Medic && p.getOwner()==player2) {
						Image img11 = new ImageIcon(this.getClass().getResource("/coulson.png")).getImage();
						b2.setIcon(new ImageIcon(img11));
					}
					if (p instanceof Ranged && p.getOwner()==player1) {
						Image img12 = new ImageIcon(this.getClass().getResource("/greena.png")).getImage();
						b2.setIcon(new ImageIcon(img12));
					}
					if (p instanceof Medic && p.getOwner()==player1) {
						Image img13 = new ImageIcon(this.getClass().getResource("/greenlanetrn.png")).getImage();
						b2.setIcon(new ImageIcon(img13));
					}
					if (p instanceof Speedster && p.getOwner()==player2) {
						Image img14 = new ImageIcon(this.getClass().getResource("/sonic.png")).getImage();
						b2.setIcon(new ImageIcon(img14));
					}
				} else {
					b2 = new JButton("");
				}
				btnpieces[i][j] = b2;
				b2.addActionListener(this);

			//	if ((i + j) % 2 == 0) {
					b2.setBackground(Color.BLACK);
					b2.setForeground(Color.WHITE);
			//	} else
				//	b2.setBackground(Color.WHITE);
				updatedBoard.add(b2);
			}
		}
		this.getContentPane().remove(board);
		board = updatedBoard;
		this.getContentPane().add(board, BorderLayout.CENTER);
		directionPressed = null; // reset
		movePressed = null;
		piecePressed = null;
		powerPressed = null;
		targetPressed = null;
		cellPressed = null;
		revive = null;
		
		south.remove(cp);    //CurrentPlayer
		JButton cpUpdated = new JButton("Current Player: " + "'" + g.getCurrentPlayer().getName() + "'");
		cpUpdated.setBackground(Color.decode("#C0C0C0"));
		cp = cpUpdated;
		south.add(cp, BorderLayout.SOUTH);
		this.setVisible(true);
	}

	public static Point getindex(JButton[][] x, JButton y) {
		for (int i = 0; i < 7; i++)
			for (int j = 0; j < 6; j++)
				if (x[i][j] == y)
					return new Point(i, j);
		return null;
	}

	
}
